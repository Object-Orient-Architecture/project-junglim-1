import Rhino
import Rhino.Geometry as geo


def get_area(curve):
    # 폐곡선을 받아서 면적을 내보낸다.
    area_properties = Rhino.Geometry.AreaMassProperties.Compute(curve)
    # 면적 출력
    if area_properties:
        area = area_properties.Area
        return area
    if not area_properties:
        raise Exception("something wrong")


def get_text_point(text_geometry):
    bbox = text_geometry.GetBoundingBox(geo.Plane.WorldXY)
    center = bbox.Center
    return center


def is_pt_inside(pt, curve):
    containment = curve.Contains(pt, geo.Plane.WorldXY, 0.1)
    if containment == geo.PointContainment.Inside:
        return True
    return False


def extract_data_to_dict():
    layers = Rhino.RhinoDoc.ActiveDoc.Layers
    objects = Rhino.RhinoDoc.ActiveDoc.Objects

    object_by_layer = {}
    # key = layer.Name
    # value  = List[Object]
    for layer in layers:
        object_by_layer[layer.Name] = []

    for obj in objects:
        for layer in layers:
            if layer.Index == obj.Attributes.LayerIndex:
                object_by_layer[layer.Name].append(obj)
    return object_by_layer
